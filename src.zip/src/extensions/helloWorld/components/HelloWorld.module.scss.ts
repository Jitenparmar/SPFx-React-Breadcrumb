/* tslint:disable */
require('./HelloWorld.module.css');
const styles = {
  helloWorld: 'helloWorld_cb9baa99',
};

export default styles;
/* tslint:enable */